# MyMusic — build lewat HP tanpa Termux

Paket ini berisi proyek Android sederhana dan workflow GitHub Actions. Workflow membuat APK debug di server GitHub.

## Langkah singkat
1. Unggah file `MyMusic_Android_HP_Build.zip` ini ke repository GitHub kamu (misalnya `Dusk`).
2. Di repository, buat file baru dengan nama persis `.github/workflows/build-apk.yml`.
3. Salin isi file workflow `build-apk.yml` yang ada di dalam ZIP ini ke file GitHub tersebut, lalu Commit.
4. Buka tab Actions, pilih `Build MyMusic APK`, tekan `Run workflow` bila belum berjalan otomatis.
5. Setelah hijau, buka run tersebut dan unduh artifact `MyMusic-debug-apk`.
6. Ekstrak artifact dan instal `app-debug.apk`.

Catatan: versi ini adalah kerangka awal UI Android. Pencarian online sesungguhnya, impor musik lokal, streaming, lirik, dan pemutaran latar belakang belum diimplementasikan. Workflow juga perlu diuji pada repository pengguna.
