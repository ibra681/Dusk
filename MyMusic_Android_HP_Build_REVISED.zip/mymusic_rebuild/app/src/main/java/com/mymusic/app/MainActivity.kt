package com.mymusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF100D16)
private val Panel = Color(0xFF211A2B)
private val Purple = Color(0xFFB78AFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyMusicScreen() }
    }
}

@Composable
fun MyMusicScreen() {
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Beranda") }
    var selected by remember { mutableStateOf("Belum ada lagu dipilih") }
    val suggestions = listOf("Blinding Lights — The Weeknd", "夜に駆ける — YOASOBI", "Hati-Hati di Jalan — Tulus", "Until I Found You — Stephen Sanchez")
    val visible = suggestions.filter { query.isBlank() || it.contains(query, ignoreCase = true) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Purple)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == "Beranda", onClick = { tab = "Beranda" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Beranda") })
                NavigationBarItem(selected = tab == "Cari", onClick = { tab = "Cari" }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Cari") })
                NavigationBarItem(selected = tab == "Koleksi", onClick = { tab = "Koleksi" }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Koleksi") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(20.dp)) {
                Text("MyMusic", color = Purple, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Musikmu, dalam satu tempat", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(22.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Cari judul lagu atau artis") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp))
                Spacer(Modifier.height(22.dp))
                Text(if (tab == "Koleksi") "Koleksi musik" else if (tab == "Cari") "Hasil pencarian contoh" else "Pilihan untukmu", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                if (tab == "Koleksi") {
                    Text("Koleksi lokal akan tersedia setelah fitur impor audio ditambahkan.", color = Color.LightGray)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(visible) { song ->
                            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { selected = song }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).background(Color(0xFF38264C), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Favorite, null, tint = Purple) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(song.substringBefore(" — "), color = Color.White, fontWeight = FontWeight.Medium)
                                    Text(song.substringAfter(" — ", "Artis"), color = Color.LightGray, fontSize = 12.sp)
                                }
                                Text("▶", color = Purple)
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sedang dipilih", color = Purple, fontSize = 11.sp)
                        Text(selected, color = Color.White, fontSize = 13.sp)
                    }
                    Text("▶", color = Purple, fontSize = 22.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text("Versi awal: tampilan dan navigasi. Pencarian online serta pemutaran audio belum diaktifkan.", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}
